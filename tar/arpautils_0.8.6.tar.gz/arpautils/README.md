R utility functions for Arpa ER air quality data
