R utility functions for Arpa ER air quality data

[![DOI](https://zenodo.org/badge/doi/10.5281/zenodo.21062.svg)](http://dx.doi.org/10.5281/zenodo.21062)

